Last login: Mon Nov 25 14:52:59 on ttys000
asaffetusi@Mac ~ % mkdir Lab3
asaffetusi@Mac ~ % cd Lab3
asaffetusi@Mac Lab3 % mkdir TryDir
asaffetusi@Mac Lab3 % cd TryDir
asaffetusi@Mac TryDir % touch foo1.dat foo2.g boo3.gt6
asaffetusi@Mac TryDir % pico foo1.dat
asaffetusi@Mac TryDir % pico foo2.g
asaffetusi@Mac TryDir % cat foo1.dat
line 1 : asaf fitusi 318763430
line 2 : Qasim Yasen 214028862
asaffetusi@Mac TryDir % more foo1.dat
line 1 : asaf fitusi 318763430
line 2 : Qasim Yasen 214028862
asaffetusi@Mac TryDir % cat foo1.dat foo2.g
line 1 : asaf fitusi 318763430
line 2 : Qasim Yasen 214028862
line 1 : asaf best freind is eden
line 2 : qasam best freind is asafx
asaffetusi@Mac TryDir % ls f*
foo1.dat	foo2.g
asaffetusi@Mac TryDir % ls g*
zsh: no matches found: g*
asaffetusi@Mac TryDir % ls *1* *2* *3*
boo3.gt6	foo1.dat	foo2.g
asaffetusi@Mac TryDir % cp foo1.dat newFoo
asaffetusi@Mac TryDir % cat newFoo
line 1 : asaf fitusi 318763430
line 2 : Qasim Yasen 214028862
asaffetusi@Mac TryDir % mv newFoo Foo2
asaffetusi@Mac TryDir % mv Foo2 Lab3
asaffetusi@Mac TryDir % cd Lab3
cd: not a directory: Lab3
asaffetusi@Mac TryDir % cd ..
asaffetusi@Mac Lab3 % ls
TryDir
asaffetusi@Mac Lab3 % cd TryDir
asaffetusi@Mac TryDir % ls
Lab3		boo3.gt6	foo1.dat	foo2.g
asaffetusi@Mac TryDir % cd Lab3
cd: not a directory: Lab3
asaffetusi@Mac TryDir % mv Lab3 Foo2
asaffetusi@Mac TryDir % ls
Foo2		boo3.gt6	foo1.dat	foo2.g
asaffetusi@Mac TryDir % mv Foo2 /Users/asaffetusi/Lab3 
asaffetusi@Mac TryDir % cd ..
asaffetusi@Mac Lab3 % ls
Foo2	TryDir
