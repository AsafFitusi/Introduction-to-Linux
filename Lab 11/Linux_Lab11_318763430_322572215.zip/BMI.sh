#!/bin/bash

calculate_bmi() {
    weight=$1
    height=$2
    echo $(( (weight * 10000) / (height * height) ))
}

if [ $# -eq 1 ] || [ $# -eq 2 ]; then
    min_bmi=$1
    max_bmi=$2
    declare -A seen_clients
    
    for file in age*.data; do
        age=$(echo "$file" | grep -oE '[0-9]+')
        while read -r client_id client_name height weight; do
            bmi=$(calculate_bmi "$weight" "$height")
            if [ -z "$max_bmi" ]; then
                if [ "$bmi" -ge "$min_bmi" ] && [ -z "${seen_clients[$client_id]}" ]; then
                    echo "$client_id $age"
                    seen_clients[$client_id]=1
                fi
            else
                if [ "$bmi" -ge "$min_bmi" ] && [ "$bmi" -le "$max_bmi" ] && [ -z "${seen_clients[$client_id]}" ]; then
                    echo "$client_id $age"
                    seen_clients[$client_id]=1
                fi
            fi
        done < "$file"
    done
else
    echo "Usage: $0 <min_bmi> [<max_bmi>]"
    exit 1
fi

