#!/bin/bash

function reverseNum() {
    num=$1
    new_num=""

    while [ "$num" -ne 0 ]; do
       x=$((num % 10))
       new_num="${new_num}${x}"
       num=$((num / 10))
    done

    echo "$new_num"
}
reverseNum "$1"

function isPali() {
     num=$1
     reversed_num=$(reverseNum "$num")
     if [ "$num" -eq "$reversed_num" ]; then
        echo "is palindrome"
     else
        echo "no palindrome"
     fi
}
isPali "$1"
