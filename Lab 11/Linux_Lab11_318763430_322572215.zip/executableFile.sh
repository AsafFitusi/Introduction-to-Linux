#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

if [ ! -d "$1" ]; then
    echo "Error: '$1' is not a valid directory."
    exit 1
fi

find "$1" -type d | while read dir; do
    count=$(find "$dir" -maxdepth 1 -type f -executable | wc -l)
    echo "Directory: $dir, Executable files: $count"
done

