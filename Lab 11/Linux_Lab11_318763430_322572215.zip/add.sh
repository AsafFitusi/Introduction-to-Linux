#!/bin/bash

# Script: add
if [[ "$0" == *"add" ]]; then
    if [ $# -ne 3 ]; then
        echo "Usage: add <first_name> <second_name> <birthday>"
        exit 1
    fi
    first_name="$1"
    second_name="$2"
    birthday="$3"
    file="birthday_list"

    grep -v "^$first_name $second_name " "$file" > temp_file && echo "$first_name $second_name $birthday" >> temp_file
    sort temp_file > "$file"
    rm temp_file
    exit 0
fi

# Script: add_birthdays
if [[ "$0" == *"add_birthdays" ]]; then
    if [ $(($# % 3)) -ne 0 ] || [ $# -eq 0 ]; then
        echo "Invalid number of parameters. Usage: add_birthdays <first_name> <second_name> <birthday> [<first_name> <second_name> <birthday>]"
        exit 1
    fi
    file="birthday_list"
    while [ $# -gt 0 ]; do
        first_name="$1"
        second_name="$2"
        birthday="$3"
        grep -v "^$first_name $second_name " "$file" > temp_file && echo "$first_name $second_name $birthday" >> temp_file
        sort temp_file > "$file"
        rm temp_file
        shift 3
    done
    exit 0
fi

# Script: search_birthday
if [[ "$0" == *"search_birthday" ]]; then
    if [ $# -ne 1 ]; then
        echo "Usage: search_birthday <birthday_month>"
        exit 1
    fi
    month="$1"
    file="birthday_list"
    results=$(grep "/$month/" "$file" | cut -d ' ' -f 1,2)
    if [ -z "$results" ]; then
        echo "No people were born in month $month."
    else
        echo "$results"
    fi
    exit 0
fi

