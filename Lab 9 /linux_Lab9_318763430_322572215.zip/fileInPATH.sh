#!/bin/bash

permissions=$1
count=0

for dir in ${PATH//:/ }; do
  if [ -d "$dir" ]; then
    for file in "$dir"/*; do
      if [ -e "$file" ]; then
        file_perm=$(ls -ld "$file" | cut -c 1-10)
        if [ "$file_perm" = "$permissions" ]; then
          count=$((count + 1))
        fi
      fi
    done
  fi
done

echo "Total files with permissions: '$permissions': $count"
