#!/bin/bash
function grepN () {
       word=$1
       file=$2
       line_number=0
       while read -r line; do
           line_number=$((line_number + 1 ))
           if [[ "$line" == *"$word"* ]]; then
              echo "$line_number:$line"
           fi
         

      done<"$file"


}
grepN $1 $2
