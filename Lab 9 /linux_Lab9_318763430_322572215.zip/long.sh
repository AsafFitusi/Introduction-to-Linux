#!/bin/bash
./fact.sh 20 &
ps > out

while true; do
  :
done &

loop_pid=$!

fact_pid=$(pgrep -f fact.sh)
if [ -n "$fact_pid" ]; then
  kill -9 $fact_pid
fi

ps >> out
kill $loop_pid
echo "Process complete. Check the 'out' file for details."
