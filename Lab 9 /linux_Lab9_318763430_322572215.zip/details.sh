#!/bin/bash
echo "date: $(date)"
echo "user: $(whoami)"
echo "host: $(hostname)"

echo "Aliases:"
alias
echo "Environment Variabales:"
env

if [ $? -eq 0 ]; then
   echo "The last command executed successfully."
else
   echo "The last command failed."
fi

