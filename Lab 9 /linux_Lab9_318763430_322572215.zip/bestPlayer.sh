#!/bin/bash
file="football.txt"

search() {
  string=$1
  files="${@:2}"
  for file in $files; do
    if [ -f "$file" ]; then
      grep "$string" "$file" | while read -r line; do
        echo "$file: $line"
      done
    fi
  done
}

player() {
  name=$1
  total_goals=0
  while read -r line; do
    if echo "$line" | grep -q "$name"; then
      goals=$(echo "$line" | cut -d ' ' -f 3)
      total_goals=$((total_goals + goals))
    fi
  done < "$file"
  echo "$total_goals"
}

best_player() {
  max_goals=0
  best_player=""

  while read -r line; do
    name=$(echo "$line" | cut -d ' ' -f 1)

    if [ -z "${player_goals[$name]}" ]; then
      total_goals=$(player "$name")

      if [ "$total_goals" -gt "$max_goals" ] && [ -n "$total_goals" ]; then
        player_goals[$name]=$total_goals
        max_goals=$total_goals
        best_player="$name"
      fi
    fi
  done < "$file"

  echo "The best player is $best_player with $max_goals goals."
}

best_player
