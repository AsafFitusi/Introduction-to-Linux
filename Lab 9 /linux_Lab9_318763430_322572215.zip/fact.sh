#!/bin/bash
function fact () {
        n=$1
        if [ "$n" -eq 1 ]; then
           echo 1
        else
           echo $((n * $(fact $((n - 1)))))
        fi
}
fact $1
