#!/bin/bash

num_places=$1

temp_file="all_grades.temp"
> "$temp_file"

for file in *.grades; do
    while read -r id first_name last_name grade; do
        if [[ $grade == "-NO-" ]]; then
            echo "$id veto" >> "$temp_file"
        else
            echo "$id $first_name $last_name $grade" >> "$temp_file"
        fi
    done < "$file"
done

final_file="final_grades.temp"
> "$final_file"

while read -r id first_name last_name grade; do
    if ! grep -q "$id veto" "$temp_file"; then
        echo "$id $first_name $last_name $grade" >> "$final_file"
    fi
done < "$temp_file"

scores_file="scores.temp"
> "$scores_file"

cut -d' ' -f1-3 "$final_file" | uniq | while read -r id first_name last_name; do
    total=0
    count=0
    while read -r cid cname clast cgrade; do
        if [[ "$cid" == "$id" ]]; then
            total=$((total + cgrade))
            count=$((count + 1))
        fi
    done < "$final_file"

    if [ $count -gt 0 ]; then
        average=$((total / count))
        echo "$id $first_name $last_name $average" >> "$scores_file"
    fi
done

sorted_file="sorted_scores.temp"
sort -k4 -nr "$scores_file" > "$sorted_file"

count=0
seen_ids=""
while read -r id first_name last_name score; do
   if ! echo "$seen_ids" | grep -q "$id"; then
        if [ $count -lt $num_places ]; then
            count=$((count + 1))
            seen_ids="$seen_ids $id"
            echo "$count) $id $first_name $last_name"
        else
            break
        fi
    fi
done < "$sorted_file"

if [ $count -lt $num_places ]; then
    echo "Not enough interviewees"
fi

