#!/bin/bash

function UniqD() {
    sorted_lines=$(sort "$1")
    previous_line=""
    count=0

    while read -r line; do
        if [[ "$line" == "$previous_line" ]]; then
            count=$((count + 1))
        else
            if [[ $count -gt 1 ]]; then
                echo "$previous_line"
            fi
            previous_line="$line"
            count=1
        fi
    done <<< "$sorted_lines"

    if [[ $count -gt 1 ]]; then
        echo "$previous_line"
    fi
}

UniqD "$1"
