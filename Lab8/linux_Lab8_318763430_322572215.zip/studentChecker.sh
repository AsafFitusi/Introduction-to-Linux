#!/bin/bash

function calcStdNames () {
  LINE_NUM=1
  while read line; do
     echo "$line"


  done < StudentsFile | sort -k1| cut -d' ' -f1| uniq -c
}
calcStdNames > Names.txt

CalcGPA() {
    local StudentsFile=$1
    local YEAR=$2

    if [[ $YEAR -lt 1900 || $YEAR -gt 2010 ]]; then
        echo "Error: YEAR must be in the range 1900-2010."
        return 1
    fi

    grep " $YEAR " "$StudentsFile" 
}

CalcGPA "StudentsFile" "$1" > GPA.txt
