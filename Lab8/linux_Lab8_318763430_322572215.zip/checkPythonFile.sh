#!/bin/bash
python_file=$1
text_file=$2
output_file=$(echo "$python_file" | cut -d '.' -f1)
new_file="${output_file}Result.txt"
python3 "$python_file" > "$new_file" 
x=$(diff -u "$new_file" "$text_file" | wc -l)
if [ "$x" -gt 0 ]; then
  echo "Your python code is wrong."
else  
  echo "Your python code is correct." 
fi
