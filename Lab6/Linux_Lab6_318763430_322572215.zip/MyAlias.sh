#!/bin/bash
alias myLs="ls"
myLs
alias LsL="ls -l"
LsL
alias cdtamar="cd && cd Lab6 && ls"
cdtamar
