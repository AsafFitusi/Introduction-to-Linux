#!/bin/bash
TestArray=("Atgar Kart" "1967" "Israel")
echo ${TestArray[@]}
echo ${#TestArray[@]}
