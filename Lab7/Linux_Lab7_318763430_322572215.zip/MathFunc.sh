#!/bin/bash

function mult() {
    result=1
    for NUM in "$@"; do
        let result*=$NUM
    done
    echo $result
}
function isEven() {
    for NUM in "$@"; do
        if (( NUM % 2 == 0 )); then
            return 1  
        else
            return 0  
        fi
    done
}
function NumOfEven() {
    count=0
    for NUM in "$@"; do
        isEven $NUM
        if (( $? == 1 )); then
            let count+=1
        fi
    done
    echo $count
}


function Fibo() {
    n=$1
    a=0
    b=1
    for (( i=1 ; i<=n; i++)); do
       echo -n "$a "
       next=$((a + b))
       a=$b
       b=$next
    done
}
    
function minMax() {
         min=$1
         max=$1
     for NUM in "$@"; do
       if (( NUM > $max )); then 
         max=$NUM
       fi
       if (( NUM < $min )); then
          min=$NUM
       fi
     done
     echo min=$min, max=$max
}
read -p " Please choose one of the next function(a,c or e): a: mult c: NumOfEven  e: minMax " choosen_func
 if [[ $choosen_func == 'a' ]]; then
    echo "The result of mult is:"  $(mult "$@") "."
 elif [[ $choosen_func == 'c' ]]; then
    echo "The result of NumOfEven is:"  $(NumOfEven "$@") "."
 elif [[ $choosen_func == 'e' ]]; then
    echo "The result of minMax is:"  $(minMax "$@") "."
  else
     echo " You made an invalid choice." > Errors.er
     pico Errors.er
 fi
   
    


