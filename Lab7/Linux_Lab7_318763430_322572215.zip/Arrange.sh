#!/bin/bash

function four_letters() {
    echo "$1" | cut -c1-4
}

function num_of_files() {
    count=0
    prefix=$1
    for f in $(ls); do
        if [[ -f $f && $(four_letters "$f") == "$prefix" ]]; then
            let count+=1
        fi
    done
    echo $count
}

for file in $(ls); do
    if [[ -f $file ]]; then
        prefix=$(four_letters "$file")
        if [[ -d $prefix ]]; then
            mv "$file" "$prefix/"
        else
            count=$(num_of_files "$prefix")
            if (( count > 2 )); then
                mkdir "$prefix"
                mv "$file" "$prefix/"
            fi
        fi
    fi
done
