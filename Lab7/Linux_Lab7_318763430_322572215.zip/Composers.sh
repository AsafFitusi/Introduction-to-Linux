#!/bin/bash

function first_names() {
  cat ComposersFile|cut -d " " -f1 -f3
}
first_names > FirstYear

read -p " enter a parameter (FN,SN,Year,Country): " p

if [[ $p == 'FN' ]]; then
  cat ComposersFile|cut -d " " -f1 > FN
elif [[ $p == 'SN' ]]; then
  cat ComposersFile|cut -d " " -f2 > SN
elif [[ $p == 'Year' ]]; then
  cat ComposersFile|cut -d " " -f3 > Year 
elif [[ $p == 'Country' ]]; then
  cat ComposersFile|cut -d " " -f4 > Country 
fi
